/**
 * Mini WhatsApp Bot Integration Test Suite
 */

const assert = require('assert');
const commandHandler = require('../lib/commandHandler');
const antiDelete = require('../lib/antiDelete');
const contactStore = require('../lib/contactStore');
const safety = require('../lib/safety');
const config = require('../config');

console.log('🧪 Starting Mini WhatsApp Bot Integration Tests...\n');

let passedTests = 0;
let totalTests = 0;

function it(name, testFn) {
  totalTests++;
  try {
    testFn();
    console.log(`  ✅ PASS: ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`  ❌ FAIL: ${name}`);
    console.error(`     Error: ${err.message}`);
  }
}

async function runAsyncTests() {
  // Test 1: Check commands loaded
  it('Loads the core commands: viewonce, antidelet, mini, menu, movie, anime, series, mute, unmute, kmovie, kseries', () => {
    assert.strictEqual(commandHandler.commands.size, 11, 'Expected 11 commands loaded');
    assert.ok(commandHandler.commands.has('viewonce'), 'Missing viewonce command');
    assert.ok(commandHandler.commands.has('antidelet'), 'Missing antidelet command');
    assert.ok(commandHandler.commands.has('mini'), 'Missing mini command');
    assert.ok(commandHandler.commands.has('menu'), 'Missing menu command');
    assert.ok(commandHandler.commands.has('movie'), 'Missing movie command');
    assert.ok(commandHandler.commands.has('anime'), 'Missing anime command');
    assert.ok(commandHandler.commands.has('series'), 'Missing series command');
    assert.ok(commandHandler.commands.has('mute'), 'Missing mute command');
    assert.ok(commandHandler.commands.has('unmute'), 'Missing unmute command');
    assert.ok(commandHandler.commands.has('kmovie'), 'Missing kmovie command');
    assert.ok(commandHandler.commands.has('kseries'), 'Missing kseries command');
  });

  // Test 2: Check aliases resolution
  it('Resolves command aliases correctly', () => {
    assert.strictEqual(commandHandler.getCommand('vv')?.name, 'viewonce');
    assert.strictEqual(commandHandler.getCommand('videwonce')?.name, 'viewonce');
    assert.strictEqual(commandHandler.getCommand('rvo')?.name, 'viewonce');
    assert.strictEqual(commandHandler.getCommand('antidelete')?.name, 'antidelet');
    assert.strictEqual(commandHandler.getCommand('antidel')?.name, 'antidelet');
    assert.strictEqual(commandHandler.getCommand('antirevoke')?.name, 'antidelet');
    assert.strictEqual(commandHandler.getCommand('minibot')?.name, 'mini');
    assert.strictEqual(commandHandler.getCommand('switch')?.name, 'mini');
    assert.strictEqual(commandHandler.getCommand('power')?.name, 'mini');
    assert.strictEqual(commandHandler.getCommand('help')?.name, 'menu');
    assert.strictEqual(commandHandler.getCommand('ping')?.name, 'menu');
    assert.strictEqual(commandHandler.getCommand('film')?.name, 'movie');
    assert.strictEqual(commandHandler.getCommand('cinema')?.name, 'movie');
    assert.strictEqual(commandHandler.getCommand('ani')?.name, 'anime');
    assert.strictEqual(commandHandler.getCommand('watchanime')?.name, 'anime');
    assert.strictEqual(commandHandler.getCommand('tv')?.name, 'series');
    assert.strictEqual(commandHandler.getCommand('kdrama')?.name, 'kseries');
    assert.strictEqual(commandHandler.getCommand('kmovies')?.name, 'kmovie');
    assert.strictEqual(commandHandler.getCommand('koreanmovie')?.name, 'kmovie');
    assert.strictEqual(commandHandler.getCommand('koreanseries')?.name, 'kseries');
    assert.strictEqual(commandHandler.getCommand('closegroup')?.name, 'mute');
    assert.strictEqual(commandHandler.getCommand('opengroup')?.name, 'unmute');
  });

  // Test 3: Prefix parsing & standalone keywords
  it('Detects prefixes and standalone menu keywords', () => {
    assert.strictEqual(commandHandler.getPrefix('.viewonce'), '.');
    assert.strictEqual(commandHandler.getPrefix('!antidelet'), '!');
    assert.strictEqual(commandHandler.getPrefix('#mini'), '#');
    assert.strictEqual(commandHandler.getPrefix('/vv'), '/');
    assert.strictEqual(commandHandler.getPrefix('hello world'), null);
  });

  // Test 4: Bot power switch functionality (.mini on / .mini off)
  it('Manages Bot Master Power Switch (.mini on/off) and rejects old .bot command', async () => {
    safety.setBotEnabled(true);
    assert.strictEqual(safety.isBotEnabled(), true);

    const mockSock = {
      sendMessage: async (jid, content) => content
    };

    // Old .bot off command should be completely ignored and NOT turn off the bot
    const oldBotOffMsg = {
      key: { remoteJid: '923116469820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.bot off' }
    };
    await commandHandler.handleMessage(mockSock, oldBotOffMsg);
    assert.strictEqual(safety.isBotEnabled(), true, '.bot off must NOT power off the bot');

    // Turn off using .mini off
    const miniOffMsg = {
      key: { remoteJid: '923116469820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.mini off' }
    };
    await commandHandler.handleMessage(mockSock, miniOffMsg);
    assert.strictEqual(safety.isBotEnabled(), false, '.mini off must power off the bot');

    // While offline, commands from non-owners should be ignored
    const nonOwnerMsg = {
      key: { remoteJid: '12345678@s.whatsapp.net', fromMe: false },
      message: { conversation: '.viewonce' }
    };
    const handled = await commandHandler.handleMessage(mockSock, nonOwnerMsg);
    assert.strictEqual(handled, false, 'Non-owner command should be blocked when bot is offline');

    // While offline, old .bot on should NOT wake up the bot
    const oldBotOnMsg = {
      key: { remoteJid: '923116469820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.bot on' }
    };
    const oldWakeHandled = await commandHandler.handleMessage(mockSock, oldBotOnMsg);
    assert.strictEqual(oldWakeHandled, false, 'Old .bot on command must NOT wake up the bot');
    assert.strictEqual(safety.isBotEnabled(), false, 'Bot must remain offline');

    // While offline, owner waking it up with .mini on must succeed
    const ownerWakeMsg = {
      key: { remoteJid: '923116469820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.mini on' }
    };
    const wakeHandled = await commandHandler.handleMessage(mockSock, ownerWakeMsg);
    assert.strictEqual(wakeHandled, true, 'Owner .mini on command should be processed');
    assert.strictEqual(safety.isBotEnabled(), true, 'Bot should now be re-enabled via .mini on');
  });

  // Test 5: ContactStore resolves group participant LIDs to Phone numbers
  it('Resolves participant LIDs to real phone numbers and names', async () => {
    const mockSock = {
      groupMetadata: async (gid) => ({
        id: gid,
        subject: 'Gaming Squad 🎮',
        participants: [
          {
            id: '923019876543@s.whatsapp.net',
            jid: '923019876543@s.whatsapp.net',
            lid: '230382129692888@lid',
            name: 'Ali Gamer'
          }
        ]
      })
    };

    const resolved = await contactStore.resolveSender(mockSock, {
      participant: '230382129692888@lid',
      from: '120363159007450337@g.us',
      isGroup: true
    });

    assert.strictEqual(resolved.phone, '923019876543', 'Should map LID to real phone number');
    assert.strictEqual(resolved.name, 'Ali Gamer', 'Should map name from participant');
    assert.strictEqual(resolved.display, '+923019876543 (Ali Gamer)', 'Display should format cleanly');
  });

  // Test 6: Anti-Delete recovers ephemeral wrapped messages silently
  it('Recovers ephemeral/disappearing messages silently to owner inbox', async () => {
    antiDelete.enabled = true;

    // Ephemeral message structure (disappearing messages on)
    const ephemeralSample = {
      key: {
        id: 'EPHEMERAL_MSG_101',
        remoteJid: '120363159007450337@g.us',
        participant: '230382129692888@lid',
        fromMe: false
      },
      message: {
        ephemeralMessage: {
          message: {
            conversation: 'This is a secret ephemeral message!'
          }
        }
      }
    };

    antiDelete.storeMessage(ephemeralSample);

    let sentToJid = null;
    let sentContent = null;

    const mockSock = {
      groupMetadata: async (gid) => ({
        id: gid,
        subject: 'Secret Club 🤫',
        participants: [
          {
            id: '923019876543@s.whatsapp.net',
            jid: '923019876543@s.whatsapp.net',
            lid: '230382129692888@lid',
            notify: 'Ahmed'
          }
        ]
      }),
      sendMessage: async (jid, content) => {
        sentToJid = jid;
        sentContent = content;
        return { key: { id: 'RESP_EPHEMERAL' } };
      }
    };

    // Ephemeral revoke structure
    const revokeMsg = {
      key: { remoteJid: '120363159007450337@g.us' },
      message: {
        ephemeralMessage: {
          message: {
            protocolMessage: {
              type: 0, // REVOKE
              key: { id: 'EPHEMERAL_MSG_101', participant: '230382129692888@lid' }
            }
          }
        }
      }
    };

    await antiDelete.handleRevoke(mockSock, revokeMsg);

    const expectedOwnerJid = safety.getOwnerJid();
    assert.strictEqual(sentToJid, expectedOwnerJid, 'Should silently send to owner inbox only');
    assert.ok(sentContent?.text?.includes('This is a secret ephemeral message!'), 'Recovered text should match');
    assert.ok(sentContent?.text?.includes('923019876543'), 'Should identify the actual phone number, not LID or group ID');
    assert.ok(sentContent?.text?.includes('Secret Club'), 'Should display source group name');
  });

  // Test 7: View-Once resolves the quoted sender instead of command executor
  it('Resolves quoted author in View-Once command instead of group ID or executor', async () => {
    const viewonceCmd = commandHandler.getCommand('viewonce');
    assert.ok(viewonceCmd, 'Missing viewonce command');

    // Store a View-Once image in memory cache as if received earlier
    const originalViewOnce = {
      key: {
        id: 'VO_IMG_777',
        remoteJid: '120363159007450337@g.us',
        participant: '230382129692888@lid',
        fromMe: false
      },
      pushName: 'Zainab',
      message: {
        viewOnceMessageV2: {
          message: {
            imageMessage: {
              mimetype: 'image/jpeg',
              caption: 'My private photo'
            }
          }
        }
      }
    };
    antiDelete.storeMessage(originalViewOnce);

    let sentToJid = null;
    let sentOptions = null;
    let deletedKey = null;

    const mockSock = {
      groupMetadata: async (gid) => ({
        id: gid,
        subject: 'Best Friends 🌟',
        participants: [
          {
            id: '923098887776@s.whatsapp.net',
            jid: '923098887776@s.whatsapp.net',
            lid: '230382129692888@lid',
            name: 'Zainab'
          }
        ]
      }),
      sendMessage: async (jid, content, options) => {
        if (content.delete) {
          deletedKey = content.delete;
          return;
        }
        sentToJid = jid;
        sentOptions = content;
        return { key: { id: 'SENT_VO_777' } };
      }
    };

    // User executes .vv as reply to the view-once image in the group
    const userCommandMsg = {
      key: {
        id: 'CMD_VV_1',
        remoteJid: '120363159007450337@g.us',
        participant: '923056499820@s.whatsapp.net', // The bot owner typing .vv
        fromMe: true
      },
      message: {
        extendedTextMessage: {
          text: '.vv',
          contextInfo: {
            stanzaId: 'VO_IMG_777',
            participant: '230382129692888@lid',
            quotedMessage: originalViewOnce.message.viewOnceMessageV2.message
          }
        }
      }
    };

    await viewonceCmd.execute({
      sock: mockSock,
      msg: userCommandMsg,
      from: '120363159007450337@g.us',
      sender: '923056499820@s.whatsapp.net',
      isGroup: true
    });

    const expectedOwnerJid = safety.getOwnerJid();
    assert.strictEqual(sentToJid, expectedOwnerJid, 'Must deliver silently to user private inbox');
    assert.strictEqual(deletedKey?.id, 'CMD_VV_1', 'Must self-delete the command message from group');
    assert.ok(sentOptions?.caption?.includes('923098887776'), 'Caption must contain the true sender phone number');
    assert.ok(!sentOptions?.caption?.includes('120363159007450337'), 'Caption must NOT show the group ID as sender');
    assert.ok(sentOptions?.caption?.includes('Best Friends'), 'Caption must show source group name');
  });

  // Test 8: Status API endpoint
  it('Serves valid status endpoint through Express', async () => {
    const { app } = require('../index');
    const req = {};
    let statusResult = null;
    const res = {
      json: (data) => {
        statusResult = data;
      }
    };

    const routes = app._router.stack.filter(r => r.route?.path === '/api/status');
    assert.ok(routes.length > 0, 'Status route should exist');
    routes[0].route.stack[0].handle(req, res);

    assert.ok(statusResult !== null, 'Status should return JSON');
    assert.strictEqual(typeof statusResult.botEnabled, 'boolean');
    assert.strictEqual(typeof statusResult.status, 'string');
    assert.strictEqual(statusResult.botName, config.botName);
  });

  // Test 9: WhatsApp participantPn / senderPn resolution
  it('Resolves real phone numbers directly via participantPn and senderPn', async () => {
    // 1. participantPn in group
    const resolvedGroup = await contactStore.resolveSender(null, {
      participant: '219305375465508@lid',
      participantPn: '923336610087@s.whatsapp.net',
      pushName: 'Zam Online Shop',
      isGroup: true
    });
    assert.strictEqual(resolvedGroup.phone, '923336610087');
    assert.strictEqual(resolvedGroup.display, '+923336610087 (Zam Online Shop)');

    // 2. senderPn in DM
    const resolvedDm = await contactStore.resolveSender(null, {
      from: '153678577160378@lid',
      senderPn: '639363881585@s.whatsapp.net',
      pushName: 'ELL TRI',
      isGroup: false
    });
    assert.strictEqual(resolvedDm.phone, '639363881585');
    assert.strictEqual(resolvedDm.display, '+639363881585 (ELL TRI)');
  });

  // Test 10: Self-chat anti-delete recovery
  it('Recovers self-chat deleted messages so users can verify anti-delete directly', async () => {
    const selfMsgId = 'SELF_TEST_DELETE_99';
    const ownerJid = safety.getOwnerJid();

    antiDelete.storeMessage({
      key: {
        id: selfMsgId,
        remoteJid: ownerJid,
        fromMe: true
      },
      message: {
        conversation: 'Testing anti-delete in self chat'
      }
    });

    let sentTarget = null;
    let sentPayload = null;

    const mockSock = {
      sendMessage: async (jid, content) => {
        sentTarget = jid;
        sentPayload = content;
        return { key: { id: 'RESP_SELF' } };
      }
    };

    await antiDelete.handleRevoke(mockSock, {
      revokedId: selfMsgId,
      chatJid: ownerJid,
      fromMe: true
    });

    assert.strictEqual(sentTarget, ownerJid, 'Must deliver recovered message to owner inbox');
    assert.ok(sentPayload?.text?.includes('Testing anti-delete in self chat'), 'Recovered text must match');
    assert.ok(sentPayload?.text?.includes('Self Chat'), 'Source should be Self Chat');
  });

  // Test 11: Movie Search and Dual Audio streaming link generation
  it('Searches movie metadata and generates Dual Audio streaming player links', async () => {
    const movieCmd = commandHandler.getCommand('movie');
    assert.ok(movieCmd, 'Missing movie command');

    let sentPayload = null;
    const mockSock = {
      sendMessage: async (jid, content) => {
        sentPayload = content;
        return { key: { id: 'RESP_MOVIE' } };
      }
    };

    const mockMsg = {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: true },
      message: { conversation: '.movie titanic' }
    };

    await movieCmd.execute({
      sock: mockSock,
      msg: mockMsg,
      from: '923056499820@s.whatsapp.net',
      sender: '923056499820@s.whatsapp.net',
      args: ['titanic']
    });

    assert.ok(sentPayload !== null, 'Should send response for movie search');
    const responseText = sentPayload.caption || sentPayload.text || '';
    assert.ok(responseText.toUpperCase().includes('TITANIC'), 'Response should mention Titanic');
    assert.ok(responseText.includes('embed.su'), 'Response should contain verified HD streaming link');
    assert.ok(responseText.includes('Hindi Dubbed'), 'Response should mention Dual Audio / Hindi Dubbed');
    assert.ok(responseText.includes('desicinemas.tv'), 'Response should mention DesiCinemas streaming portal');
    assert.ok(responseText.includes('hdmovie2.st'), 'Response should mention HDMovie2 streaming portal');
    assert.ok(!responseText.includes('vegamovies'), 'Response must NOT contain vegamovies');
    assert.ok(responseText.includes('PLAY DIRECTLY IN WHATSAPP'), 'Response should include direct in-WhatsApp player');
  });

  // Test 12: Anime Search and Episode extraction
  it('Searches anime on AniKoto and generates Episode streaming player links with Sub/Dub', async () => {
    const animeCmd = commandHandler.getCommand('anime');
    assert.ok(animeCmd, 'Missing anime command');

    let sentPayload = null;
    const mockSock = {
      sendMessage: async (jid, content) => {
        sentPayload = content;
        return { key: { id: 'RESP_ANIME' } };
      }
    };

    const mockMsg = {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: true },
      message: { conversation: '.anime solo leveling 2' }
    };

    await animeCmd.execute({
      sock: mockSock,
      msg: mockMsg,
      from: '923056499820@s.whatsapp.net',
      sender: '923056499820@s.whatsapp.net',
      args: ['solo', 'leveling', '2']
    });

    assert.ok(sentPayload !== null, 'Should send response for anime search');
    const responseText = sentPayload.caption || sentPayload.text || '';
    assert.ok(responseText.toUpperCase().includes('SOLO LEVELING'), 'Response should mention Solo Leveling');
    assert.ok(responseText.includes('EPISODE 2'), 'Response should indicate selected Episode 2');
    assert.ok(responseText.includes('anikoto.cz/watch/'), 'Response should contain AniKoto watch URL');
  });

  // Test 13: Series Search and Season/Episode parsing (Hollywood / Bollywood / K-Drama)
  it('Searches TV series and generates Season/Episode streaming links with Dual Audio', async () => {
    const seriesCmd = commandHandler.getCommand('series');
    assert.ok(seriesCmd, 'Missing series command');

    let sentPayload = null;
    const mockSock = {
      sendMessage: async (jid, content) => {
        sentPayload = content;
        return { key: { id: 'RESP_SERIES' } };
      }
    };

    const mockMsg = {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: true },
      message: { conversation: '.series squid game 2 1' }
    };

    await seriesCmd.execute({
      sock: mockSock,
      msg: mockMsg,
      from: '923056499820@s.whatsapp.net',
      sender: '923056499820@s.whatsapp.net',
      args: ['squid', 'game', '2', '1']
    });

    assert.ok(sentPayload !== null, 'Should send response for series search');
    const responseText = sentPayload.text || sentPayload.caption || '';
    assert.ok(responseText.toUpperCase().includes('SQUID GAME'), 'Response should mention Squid Game');
    assert.ok(responseText.includes('Season 2, Episode 1'), 'Response should show Season 2, Episode 1');
    assert.ok(responseText.includes('embed.su/embed/tv/'), 'Response should contain verified TV streaming link');
    assert.ok(responseText.includes('Hindi Dubbed'), 'Response should mention Dual Audio / Hindi Dubbed');
    assert.ok(responseText.includes('desicinemas.tv'), 'Response should link to DesiCinemas series portal');
    assert.ok(responseText.includes('hdmovie2.st'), 'Response should link to HDMovie2 series portal');
    assert.ok(!responseText.includes('vegamovies'), 'Response must NOT contain vegamovies');
  });

  // Test 14: Group Admin Mute and Unmute commands
  it('Enforces group admin permissions and updates group settings for .mute and .unmute', async () => {
    const muteCmd = commandHandler.getCommand('mute');
    const unmuteCmd = commandHandler.getCommand('unmute');
    assert.ok(muteCmd && unmuteCmd, 'Missing mute or unmute command');

    let settingUpdated = null;
    let sentPayload = null;

    const mockSock = {
      user: { id: '923999999999:1@s.whatsapp.net' }, // Bot account
      groupMetadata: async (gid) => ({
        id: gid,
        participants: [
          { id: '923999999999@s.whatsapp.net', admin: 'admin' }, // Bot is admin
          { id: '923001112233@s.whatsapp.net', admin: 'admin' }, // Group Admin
          { id: '923004445566@s.whatsapp.net', admin: null },    // Regular member
        ]
      }),
      groupSettingUpdate: async (gid, setting) => {
        settingUpdated = setting;
      },
      sendMessage: async (jid, content) => {
        sentPayload = content;
        return { key: { id: 'RESP_GRP' } };
      }
    };

    // 1. Regular member tries to mute -> denied
    sentPayload = null;
    await muteCmd.execute({
      sock: mockSock,
      msg: { key: {} },
      from: '120363999@g.us',
      sender: '923004445566@s.whatsapp.net',
      isGroup: true,
      isOwner: false
    });
    assert.ok(sentPayload?.text?.includes('Permission Denied'), 'Non-admin member must be denied');

    // 2. Group Admin mutes -> succeeds
    sentPayload = null;
    settingUpdated = null;
    await muteCmd.execute({
      sock: mockSock,
      msg: { key: {} },
      from: '120363999@g.us',
      sender: '923001112233@s.whatsapp.net',
      isGroup: true,
      isOwner: false
    });
    assert.strictEqual(settingUpdated, 'announcement', 'Mute must set group to announcement mode');
    assert.ok(sentPayload?.text?.includes('GROUP MUTED'), 'Confirmation must be sent');

    // 3. Bot Owner unmutes -> succeeds
    sentPayload = null;
    settingUpdated = null;
    await unmuteCmd.execute({
      sock: mockSock,
      msg: { key: {} },
      from: '120363999@g.us',
      sender: '923056499820@s.whatsapp.net',
      isGroup: true,
      isOwner: true
    });
    assert.strictEqual(settingUpdated, 'not_announcement', 'Unmute must set group to not_announcement mode');
    assert.ok(sentPayload?.text?.includes('GROUP UNMUTED'), 'Confirmation must be sent');
  });

  // Test 15: Anti-Ban Security Modes & Spam Strike Protection
  it('Enforces anti-ban security modes and spam strike shield', async () => {
    // 1. Security mode management
    safety.setMode('self');
    assert.strictEqual(safety.getMode(), 'self');

    const mockSock = {
      sendMessage: async (jid, content) => ({ key: { id: 'TEST_ID' }, message: content }),
      readMessages: async () => true,
      sendPresenceUpdate: async () => true
    };

    // Non-owner in self mode should be silently ignored
    const strangerMsg = {
      key: { remoteJid: '999888777@s.whatsapp.net', fromMe: false },
      message: { conversation: '.menu' }
    };
    let handled = await commandHandler.handleMessage(mockSock, strangerMsg);
    assert.strictEqual(handled, false, 'Non-owner command must be ignored in self mode');

    // Switch to groups mode: stranger DM ignored, group accepted
    safety.setMode('groups');
    handled = await commandHandler.handleMessage(mockSock, strangerMsg);
    assert.strictEqual(handled, false, 'Stranger DM must be ignored in groups mode');

    // Reset to public mode
    safety.setMode('public');
    assert.strictEqual(safety.getMode(), 'public');

    // 2. Spam strike shield
    const spammerId = 'spammer_12345@s.whatsapp.net';
    assert.strictEqual(safety.canExecuteCommand(spammerId), true, 'First command allowed');
    // Rapid calls trigger cooldown strikes
    assert.strictEqual(safety.canExecuteCommand(spammerId), false, 'Strike 1 blocked');
    assert.strictEqual(safety.canExecuteCommand(spammerId), false, 'Strike 2 blocked');
    assert.strictEqual(safety.canExecuteCommand(spammerId), false, 'Strike 3 blocked');
    assert.strictEqual(safety.canExecuteCommand(spammerId), false, 'Strike 4 triggers temporary block');

    const strikeInfo = safety.userStrikes.get(spammerId);
    assert.ok(strikeInfo && strikeInfo.blockedUntil > Date.now(), 'Spammer must be blocked for 60 seconds');

    // Clean up
    safety.userStrikes.delete(spammerId);
    safety.userCooldowns.delete(spammerId);
  });

  // Test 16: Korean Movie Search (.kmovie / .kmovies)
  it('Searches Korean movie metadata and generates English subtitles & dual audio streaming links', async () => {
    const kmovieCmd = commandHandler.getCommand('kmovie');
    assert.ok(kmovieCmd, 'Missing kmovie command');

    let sentPayload = null;
    const mockSock = {
      sendMessage: async (jid, content) => {
        sentPayload = content;
        return { key: { id: 'RESP_KMOVIE' } };
      }
    };

    const mockMsg = {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: true },
      message: { conversation: '.kmovie parasite' }
    };

    await kmovieCmd.execute({
      sock: mockSock,
      msg: mockMsg,
      from: '923056499820@s.whatsapp.net',
      sender: '923056499820@s.whatsapp.net',
      args: ['parasite']
    });

    assert.ok(sentPayload !== null, 'Should send response for Korean movie search');
    const responseText = sentPayload.caption || sentPayload.text || '';
    assert.ok(responseText.toUpperCase().includes('PARASITE'), 'Response should mention Parasite');
    assert.ok(responseText.includes('embed.su'), 'Response should contain Embed.su player link');
    assert.ok(responseText.includes('dramacool.ch'), 'Response should link to Dramacool portal');
    assert.ok(responseText.includes('English Subtitles'), 'Response should highlight English Subtitles');
  });

  // Test 17: Korean Series & Drama Search (.kseries / .kdrama)
  it('Searches Korean drama metadata and generates Season/Episode streaming links with English Subs & Dub', async () => {
    const kseriesCmd = commandHandler.getCommand('kseries');
    assert.ok(kseriesCmd, 'Missing kseries command');

    let sentPayload = null;
    const mockSock = {
      sendMessage: async (jid, content) => {
        sentPayload = content;
        return { key: { id: 'RESP_KSERIES' } };
      }
    };

    const mockMsg = {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: true },
      message: { conversation: '.kdrama squid game 2 1' }
    };

    await kseriesCmd.execute({
      sock: mockSock,
      msg: mockMsg,
      from: '923056499820@s.whatsapp.net',
      sender: '923056499820@s.whatsapp.net',
      args: ['squid', 'game', '2', '1']
    });

    assert.ok(sentPayload !== null, 'Should send response for K-Drama search');
    const responseText = sentPayload.caption || sentPayload.text || '';
    assert.ok(responseText.toUpperCase().includes('SQUID GAME'), 'Response should mention Squid Game');
    assert.ok(responseText.includes('Season 2, Episode 1'), 'Response should show Season 2 Episode 1');
    assert.ok(responseText.includes('embed.su/embed/tv/'), 'Response should contain Embed.su TV player link');
    assert.ok(responseText.includes('dramacool.ch'), 'Response should link to Dramacool portal');
    assert.ok(responseText.includes('English Subtitles'), 'Response should highlight English Subtitles');
  });

  // Test 18: Instant Phone Response & Protobuf Reconciliation
  it('Ensures instant delivery without artificial delay and resolves LID addresses to phone JID', async () => {
    let deliveredJid = null;
    let deliveredContent = null;
    const mockSock = {
      sendMessage: async (jid, content, options) => {
        deliveredJid = jid;
        deliveredContent = content;
        return { key: { id: 'INSTANT_MSG_123', remoteJid: jid } };
      }
    };

    // 1. Sending to @lid must normalize to real phone number
    const t0 = Date.now();
    await safety.safeSend(mockSock, '230382129692888@lid', { text: 'Test instant response' });
    const elapsed = Date.now() - t0;

    assert.ok(elapsed < 100, `Message delivery must be instant (took ${elapsed}ms, expected < 100ms)`);
    assert.ok(!deliveredJid.endsWith('@lid'), 'LID must be normalized to phone number');
    assert.strictEqual(safety.getSentMessage('INSTANT_MSG_123')?.extendedTextMessage?.text, 'Test instant response');
  });

  // Test 19: Full Power Switch Reactivation (.mini off -> mini on, minion/minioff, local format 0305...)
  it('Reactivates successfully with "mini on" (no dot), local Pakistani number format, and LID', async () => {
    const mockSock = {
      sendMessage: async (jid, content) => ({ key: { id: 'MOCK_PWR_' + Date.now(), remoteJid: jid } })
    };

    // Scenario A: Turn off with .mini off, reactivate with "mini on" (no dot)
    safety.setBotEnabled(true);
    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.mini off' }
    });
    assert.strictEqual(safety.isBotEnabled(), false, 'Bot should be offline after .mini off');

    const wakeWithNoDot = await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: 'mini on' }
    });
    assert.strictEqual(wakeWithNoDot, true, 'mini on (no dot) must be handled');
    assert.strictEqual(safety.isBotEnabled(), true, 'Bot should be reactivated via "mini on"');

    // Scenario B: Turn off with "mini off" (no dot), reactivate with ".mini on"
    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: 'mini off' }
    });
    assert.strictEqual(safety.isBotEnabled(), false, 'Bot should be offline after "mini off"');

    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.mini on' }
    });
    assert.strictEqual(safety.isBotEnabled(), true, 'Bot should be reactivated via ".mini on"');

    // Scenario C: Local Pakistani format 03056499820 turning off and on
    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '03056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.mini off' }
    });
    assert.strictEqual(safety.isBotEnabled(), false, 'Local format should power off bot');

    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '03056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: 'mini on' }
    });
    assert.strictEqual(safety.isBotEnabled(), true, 'Local format should reactivate bot via "mini on"');

    // Scenario D: minioff and minion single-word commands
    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: 'minioff' }
    });
    assert.strictEqual(safety.isBotEnabled(), false, 'minioff single word should power off bot');

    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: 'minion' }
    });
    assert.strictEqual(safety.isBotEnabled(), true, 'minion single word should power on bot');

    // Scenario E: Group chat with LID reactivation
    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '120363159007450337@g.us', participant: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: '.mini off' }
    });
    assert.strictEqual(safety.isBotEnabled(), false, 'Group .mini off should power off bot');

    await commandHandler.handleMessage(mockSock, {
      key: { remoteJid: '120363159007450337@g.us', participant: '923056499820@s.whatsapp.net', fromMe: false },
      message: { conversation: 'mini on' }
    });
    assert.strictEqual(safety.isBotEnabled(), true, 'Group mini on should reactivate bot');
  });

  // Test 20: Anti-Tag & Anti-Mass-Mention Guarantee
  it('Guarantees the bot NEVER tags or mass-mentions members in group chats', async () => {
    // 1. Verify no tagall, hidetag, or mention-all command exists in commandHandler
    assert.strictEqual(commandHandler.getCommand('tagall'), null, 'tagall command must NOT exist');
    assert.strictEqual(commandHandler.getCommand('hidetag'), null, 'hidetag command must NOT exist');
    assert.strictEqual(commandHandler.getCommand('tag'), null, 'tag command must NOT exist');
    assert.strictEqual(commandHandler.getCommand('everyone'), null, 'everyone command must NOT exist');

    // 2. Test safeSend automatically strips mentions when sending to group chats (@g.us)
    let dispatchedContent = null;
    let dispatchedOptions = null;
    const mockSock = {
      sendMessage: async (jid, content, options) => {
        dispatchedContent = content;
        dispatchedOptions = options;
        return { key: { id: 'MOCK_NOTAG_' + Date.now(), remoteJid: jid } };
      }
    };

    // Even if content or options contains mentions, safeSend must completely strip them in group chats
    await safety.safeSend(
      mockSock,
      '120363159007450337@g.us',
      {
        text: 'This is a test notification',
        mentions: ['923001112233@s.whatsapp.net', '923004445566@s.whatsapp.net'],
        contextInfo: { mentionedJid: ['923001112233@s.whatsapp.net'] }
      },
      {
        mentions: ['923001112233@s.whatsapp.net'],
        contextInfo: { mentionedJid: ['923001112233@s.whatsapp.net'] }
      }
    );

    assert.strictEqual(dispatchedContent.mentions, undefined, 'Content mentions must be stripped in groups');
    assert.strictEqual(dispatchedContent.contextInfo?.mentionedJid, undefined, 'Content contextInfo.mentionedJid must be stripped in groups');
    assert.strictEqual(dispatchedOptions.mentions, undefined, 'Option mentions must be stripped in groups');
    assert.strictEqual(dispatchedOptions.contextInfo?.mentionedJid, undefined, 'Option contextInfo.mentionedJid must be stripped in groups');

    // 3. Verify .mute and .unmute do not mention any users
    const muteCmd = commandHandler.getCommand('mute');
    dispatchedContent = null;
    await muteCmd.execute({
      sock: {
        ...mockSock,
        groupMetadata: async () => ({
          participants: [
            { id: '923056499820@s.whatsapp.net', admin: 'admin' },
            { id: '923999999999@s.whatsapp.net', admin: 'admin' }
          ]
        }),
        groupSettingUpdate: async () => true
      },
      msg: { key: {} },
      from: '120363159007450337@g.us',
      sender: '923056499820@s.whatsapp.net',
      isGroup: true,
      isOwner: true
    });

    assert.strictEqual(dispatchedContent?.mentions, undefined, 'Mute must not have mentions array');
    assert.ok(!dispatchedContent?.text?.includes('@923056499820'), 'Mute text must not contain clickable @mention');
  });

  // Test 21: DeviceSentMessage Unwrapping, Device Specifier Stripping, & Offline Alert
  it('Unwraps deviceSentMessage from companion sync, normalizes device JIDs, and alerts owner when sleeping', async () => {
    let sentToJid = null;
    let sentContent = null;
    const mockSock = {
      user: { id: '923056499820:1@s.whatsapp.net' },
      sendMessage: async (jid, content) => {
        sentToJid = jid;
        sentContent = content;
        return { key: { id: 'RESP_COMPANION', remoteJid: jid } };
      },
      readMessages: async () => true,
      sendPresenceUpdate: async () => true
    };

    // 1. Companion deviceSentMessage with device specifier (:1)
    const companionMsg = {
      key: {
        id: 'DEVICE_SENT_101',
        remoteJid: '923056499820:1@s.whatsapp.net',
        fromMe: true
      },
      message: {
        deviceSentMessage: {
          destinationJid: '923056499820@s.whatsapp.net',
          message: {
            conversation: '.ping'
          }
        }
      }
    };

    let handled = await commandHandler.handleMessage(mockSock, companionMsg);
    assert.strictEqual(handled, true, 'deviceSentMessage command should be handled');
    assert.strictEqual(sentToJid, '923056499820@s.whatsapp.net', 'Should send reply to normalized JID without device specifier');
    assert.ok(sentContent?.text?.includes('PONG') || sentContent?.text?.includes('ACTIVE') || sentContent?.text?.includes('Active'), 'Should execute .ping / .menu');

    // 2. Helpful redirect when user sends .bot
    sentToJid = null;
    sentContent = null;
    const botCmdMsg = {
      key: {
        id: 'BOT_CMD_102',
        remoteJid: '923056499820@s.whatsapp.net',
        fromMe: false
      },
      message: {
        conversation: '.bot'
      }
    };
    await commandHandler.handleMessage(mockSock, botCmdMsg);
    assert.ok(sentContent?.text?.includes('.mini on'), 'Typing .bot should provide clear guidance for .mini on / .mini off');

    // 3. Offline owner alert when bot is sleeping
    safety.setBotEnabled(false);
    sentToJid = null;
    sentContent = null;
    const offlineOwnerMsg = {
      key: {
        id: 'OFFLINE_CMD_103',
        remoteJid: '923056499820@s.whatsapp.net',
        fromMe: false
      },
      message: {
        conversation: '.menu'
      }
    };
    await commandHandler.handleMessage(mockSock, offlineOwnerMsg);
    assert.ok(sentContent?.text?.includes('OFFLINE (Sleeping)'), 'Owner should receive sleeping reminder if typing commands while bot is off');

    // Re-enable bot for clean state
    safety.setBotEnabled(true);
  });

  console.log(`\n=========================================`);
  console.log(`Test Results: ${passedTests} / ${totalTests} passed`);
  console.log(`=========================================\n`);

  if (passedTests === totalTests) {
    console.log('🎉 ALL INTEGRATION TESTS PASSED SUCCESSFULLY!\n');
    process.exit(0);
  } else {
    process.exit(1);
  }
}

runAsyncTests().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
